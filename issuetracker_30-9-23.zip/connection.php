<?php
    $db = mysqli_connect("localhost", "root","", "bugtracker");

    if (mysqli_connect_errno()) {
        echo "Failed to connect: " . mysqli_connect_error();
    }
?>