
<?php
include 'connection.php';
if(isset($_POST['add']))
{
    //$title = $_POST['title'];
    $clientname = $_POST['clientname'];
    $email = $_POST['email'];
    $date= $_POST['date'];
    $issue = $_POST['issue'];
    $priority = $_POST['priority'];
    $description = $_POST['description'];

    // $filename1 = $_FILES["myfile1"]["name"];
    // $tempname1 = $_FILES["myfile1"]["tmp_name"];
    // $folder1 = "./upload/" . $filename1;

    // $filename2 = $_FILES["myfile2"]["name"];
    // $tempname2 = $_FILES["myfile2"]["tmp_name"];
    // $folder2 = "./upload1/" . $filename2;
 
    
    $insert = mysqli_query($db,"INSERT INTO `issueraise`(`usertype`,`clientname`,`email`,`date`, `issue`, `priority`,`description`,`astatus`) 
    VALUES('Web-User','$clientname','$email','$date', '$issue', '$priority','$description','Active')");
    
   if($insert)
    {
        //   if (move_uploaded_file($tempname1, $folder1)) 
        // {
        //     if (move_uploaded_file($tempname2, $folder2)) 
        // {
	echo '<script type = "text/javascript">';
    echo 'alert("Requirement Sent Successfully!");';
    echo 'window.location.href = "userindex.php"';
    echo '</script>';
	}
    }
    else
    {
        echo "please enter required fields";
    }
// }
// }
?>





<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport"
		content="width=device-width,
				initial-scale=1" />

	<!-- Bootstrap CSS -->
	<link
	href=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
	rel="stylesheet"
	integrity=
"sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
	crossorigin="anonymous"
	/>
	<link rel="stylesheet"
		href="style.css" />
	<link rel="preconnect"
		href="https://fonts.gstatic.com" />
	<link
	href=
"https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap"
	rel="stylesheet"
	/>
	<title>GFG</title>
</head>

<style>
    *{
	margin: 0;
	padding: 0;
	font-family: 'Roboto Condensed', sans-serif;
}

/* navbar */

.navbar-nav{
	margin-right: 0 !important;
	padding-right: 100px;
}

.navbar{
	background-color: #0a193d;
	color: white !important;
}

.nav-item a{
	color: white !important;
}

.nav-item{
	padding-left: 2px;
}

.navbar-brand{
	color: white !important;
	padding-left: 100px;
}

#navbar button{
	color: white !important;
}

/* banner */

#banner-container{
	/*background-color: #0a193d;*/
	color: white !important;
	padding-top: 80px;
	padding-bottom: 80px;
    
	
}

#banner-row img{
	max-width: 70%;
	height: auto;
	display: block;
	padding-left: 30px;
}

#banner-row h2,h3, p{
	padding-left: 20px;
	padding-top: 20px;
	text-align: center;
}


#banner-row a{
	background-color: white !important;
	color: black !important;
	border: none;
	margin-left: 20px;
	margin-top: 20px;
	
}
#banner-col{

	/*padding-left: 20px;*/
}
/* service */
#service{
	padding-top: 80px;
	padding-bottom: 80px;
}

#service h1{
	padding-bottom: 70px;
}

/* about */

#about{
	padding-top: 80px;
	padding-bottom: 80px;
}

#about h1{
	padding-bottom: 70px;
}

#about-col ul{
	padding-top: 50px;
	padding-left: 50px;
}

#about-col ul li{
	padding-top: 15px;
	
}

/* product */

#product{
	padding-top: 80px;
	padding-bottom: 80px;
}

#product h1{
	padding-bottom: 70px;
}

#product-col2 ul{
	padding-top: 90px;
}

#product-col2 ul li{
	padding-top: 15px;
}

/* social */

#social{
	padding-top: 80px;
	padding-bottom: 80px;
}

#social h1{
	padding-bottom: 70px;
}

.social-col a:hover img{
transform: translateY(-10px);
}

#social-row{
	flex-direction: row;
}

/* footer */

.mb-3{
padding-top: 10px;
}
.img{
  background: url('./images/bg.jpg')no-repeat;
  width: 100%;
  height: 100vh;
  background-size: cover;
  background-position: center;
  position: relative;
}

/* media */
@media only screen and (max-width: 987px){
	.navbar-brand{
		padding-left: 0px;
	}
    .img{
  background: url('./images/bg.jpg')no-repeat;
  width: 100%;
  height: 150vh;
  background-size: cover;
  background-position: center;
  position: relative;
}
}

@media only screen and (max-width: 768px){
	#banner-row img{
		padding-top: 20px;
	}

.social-col{
	width: 33%;
}

}


</style>
<body>
	<section id="navbar">
	<nav class="navbar navbar-expand-lg navbar-light">
		<div class="container-fluid">
		
        <a class="navbar-brand" href="./"><img src="images/111.png" alt="Logo" style="height: 50px;"></a>
			</a>
		<button
			class="navbar-toggler"
			type="button"
			data-bs-toggle="collapse"
			data-bs-target="#navbarSupportedContent"
			aria-controls="navbarSupportedContent"
			aria-expanded="false"
			aria-label="Toggle navigation"
		>
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse"
			id="navbarSupportedContent">
			<ul class="navbar-nav m-auto">
			<li class="nav-item">
				<a class="nav-link active"
				aria-current="page"
				href="#">Home</a>
			</li>
			<li class="nav-item">
				<a class="nav-link"
				href="#service">Services</a>
			</li>
			<li class="nav-item">
				<a class="nav-link"
				href="#about">About Us</a>
			</li>
			<li class="nav-item">
				<a class="nav-link"
				href="#product">Products</a>
			</li>
			<li class="nav-item">
				<a class="nav-link"
				href="#social">Contact Us</a>
			</li>
			</ul>
		</div>
		</div>
	</nav>
	</section>

	<!-- banner -->
<center><div class="col-lg-6" style="padding-top:20px">
<div class="card">
<div class="card-header">
<strong>Please Enter the Requirement</strong> 
</div>
<div class="card-body card-block">
<form action="#" method="POST" class="form-horizontal" enctype="multipart/form-data">
<div class="row form-group">
<div class="col col-md-3"><label for="text-input" class=" form-control-label">Name</label></div>
<div class="col-12 col-md-9"><input type="text" name="clientname" id="text-input" name="text-input" placeholder="" class="form-control" required><small class="form-text text-muted"> </small></div>
</div>
</br>
<!--div class="row form-group">
<div class="col col-md-3"><label for="text-input" class=" form-control-label">Subject</label></div>
<div class="col-12 col-md-9"><input type="text" name="title" id="text-input" name="text-input" placeholder="" class="form-control"><small class="form-text text-muted"> </small></div>
</div-->

<div class="row form-group">
<div class="col col-md-3"><label for="text-input" class=" form-control-label">Enter Email</label></div>
<div class="col-12 col-md-9"><input type="email" id="email" name="email" name="text-input" placeholder="abc@gmail.com" class="form-control" required><small class="form-text text-muted"> </small></div>
</div></br>

<div class="row form-group">
<div class="col col-md-3"><label for="text-input" class=" form-control-label">Date</label></div>
<div class="col-12 col-md-9"><input type="date" name="date" id="text-input" name="text-input" placeholder="" class="form-control" required><small class="form-text text-muted"> </small></div>
</div></br>

<div class="row form-group">
<div class="col col-md-3"><label for="select" class=" form-control-label">Requirement type</label></div>
<div class="col-12 col-md-9">
<select name="issue" id="select" class="form-control" required>
<option value="0">Please select</option>
<option value="Web-correction">Web-correction</option>
<option value="Website-requirement">Website-requirement</option>
<option value="Software-requirement">Software-requirement</option>
</select>
</div>
</div></br>

<div class="row form-group">
<div class="col col-md-3"><label for="select" class=" form-control-label">Priority </label></div>
<div class="col-12 col-md-9">
<select name="priority" id="select" class="form-control" required>
<option value="0">Please select</option>
<option value="High">High</option>
<option value="Low">Low</option>
</select>
</div>
</div></br>

<div class="row form-group">
<div class="col col-md-3"><label for="textarea-input" class=" form-control-label">Description</label></div>
<div class="col-12 col-md-9"><textarea name="description" id="textarea-input" rows="9" placeholder="Content..." class="form-control" required></textarea></div>
</div></br>


<!--div class="row form-group">
<div class="col col-md-3"><label for="file-input" class=" form-control-label">Image 1</label></div>
<div class="col-12 col-md-9"><input type="file" id="file-input" name="myfile1" class="form-control-file"></div>
</div></br>

<div class="row form-group">
<div class="col col-md-3"><label for="file-input" class=" form-control-label">Image 2</label></div>
<div class="col-12 col-md-9"><input type="file" id="file-input" name="myfile2" class="form-control-file"></div-->
</div></br>

</div>
<div class="row form-group" style="padding-bottom:20px">
<div class="col-md-12">
<button type="submit" name="add" class="btn btn-success">Submit</button>
<button type="button" class="btn btn-danger">Reset</button>
</form>
</div>
</div></center>
</br>
</br>

	<!-- footer -->
	<section id="footer" style="background-color: #0a193d;">
	<section id="banner">
		<div class="container-fluid" id="banner-container">
		<div class="row" id="banner-row">
			<div class="col-md-4" id="footer-col1">
			<center><h3>My Website</h3></center>
				
<p>
				At XYZ we believe that customers should
				always get easy-to-use, best in the kind
				and fast services.xyz has achieved
				standards which helps customer to
				achieve satisfaction and realize
				value for their hard earned money.
			</p>

			</div>
			<div class="col-md-4" id="footer-col2">
			<center><h3>Contact Us</h3></center>
				
<p>Call Us- 1800-121-6532</p>

				
<p>Email Us- support@xyz.com</p>

			</div>

			<div class="col-md-4" id="footer-col2">
			<h3>Subscribe To Newsletter</h3>
			<form>
				<div class="mb-3">
				<input
					type="email"
					placeholder="Enter Your Email"
					class="form-control"
					id="exampleInputEmail1"
					aria-describedby="emailHelp"
				/>
				<div id="emailHelp"
					class="form-text">
					We'll never share your email with anyone else.
				</div>
				</div>
				<button type="submit"
						class="btn btn-primary">
						Submit
				</button>
			</form>
			</div>
		</div>
		</div>
	</section>
	</section>

	<!-- Optional JavaScript; choose one of the two! -->

	<!-- Option 1: Bootstrap Bundle with Popper -->
	<script
	src=
"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
	integrity=
"sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
	crossorigin="anonymous"
	></script>
</body>
</html>
