<?php
include "connection.php";
$id1 = mysqli_real_escape_string($db,$_GET['clientname']);
$id = mysqli_real_escape_string($db,$_GET['id']);
$id3 = mysqli_real_escape_string($db,$_GET['id3']);
//$title = mysqli_real_escape_string($db,$_GET['title']); //agent name
?>

<?php
if(isset($_POST['update']))
{
	//$id = $_POST['id'];
    $closedate = $_POST['closedate'];
   // $clientname = $_POST['clientname'];
    $status1  =$_POST['status'];
    $resolution=$_POST['resolution'];
    
    
    
   $update="update issueraise set closedate='$closedate',status='$status1',resolution='$resolution' where id1='$id' ";
    $insert = mysqli_query($db,$update);
   if($insert)
    {
        echo '<script type = "text/javascript">';
        //echo 'alert("Mail sent Successfully!");';
        echo 'window.location.href = "view-requirement.php?&id"'.$id;
        echo '</script>';
    }
    else
    {
       echo "please enter required fields";
    }
}