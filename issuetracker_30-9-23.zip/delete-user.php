


<?php
session_start();
include "connection.php";
$id = mysqli_real_escape_string($db,$_GET['id']);
 $id1 = mysqli_real_escape_string($db,$_GET['id1']);

    //$reject = $_POST['reject'];

$select = "DELETE FROM `tracker_login` WHERE id = '$id1'";
    $result = mysqli_query($db, $select);
if(isset($result)){
   echo '<script type = "text/javascript">';
   echo 'alert("Do you really want to Delete?");';
    echo header("location: view-user-details.php?id=".$id);

   echo '</script>';
}
?>